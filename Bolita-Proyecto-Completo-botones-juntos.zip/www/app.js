(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const today = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const money = n => '$'+Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
  const esc = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const load = (k, fallback) => { try { const v=JSON.parse(localStorage.getItem(k)); return v ?? fallback; } catch { return fallback; } };
  let players=load('bolita_players',[]), entries=load('bolita_entries',[]), session='Mediodía', pending=[];
  $('date').value=today(); $('history-date').value=today(); $('report-date').value=today();
  const save=()=>{localStorage.setItem('bolita_players',JSON.stringify(players));localStorage.setItem('bolita_entries',JSON.stringify(entries));};
  const toast=msg=>{const t=$('toast');t.textContent=msg;t.classList.remove('hidden');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.add('hidden'),2600);};
  const currentDate=()=> $('date').value||today();
  const forSession=(date=currentDate(), sess=session)=>entries.filter(e=>e.date===date&&e.session===sess);
  const entryAmount=e=>Number(e.amount||0)*Number(e.units||1);
  const sum=list=>list.reduce((a,e)=>a+entryAmount(e),0);
  function renderPlayers(){
    const selected=$('player').value;
    $('player').innerHTML='<option value="">Selecciona un jugador</option>'+players.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
    if(players.some(p=>p.id===selected))$('player').value=selected;
    const rsel=$('report-player').value||'Todos';
    $('report-player').innerHTML='<option value="Todos">Todos los jugadores</option>'+players.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
    if(rsel==='Todos'||players.some(p=>p.id===rsel))$('report-player').value=rsel;
    $('players-list').innerHTML=players.length?players.map(p=>{const total=sum(entries.filter(e=>e.playerId===p.id));return `<div class="person-row"><div><strong>${esc(p.name)}</strong><small>${entries.filter(e=>e.playerId===p.id).length} jugadas guardadas · Total ${money(total)}</small></div><button class="delete" data-delete-player="${esc(p.id)}">Eliminar</button></div>`}).join(''):'<p class="empty">Todavía no hay jugadores.</p>';
  }
  function renderSession(){
    const list=forSession();const total=sum(list);$('total').textContent=money(total);$('fee').textContent=money(total*.1);$('net').textContent=money(total*.9);$('session-count').textContent=list.length;
    $('session-plays').innerHTML=list.length?list.map(e=>`<div class="play-row"><div class="play-main"><strong>${esc(e.display)} <span class="badge-type">${esc(e.type)}</span></strong><small>${esc(players.find(p=>p.id===e.playerId)?.name||'Jugador eliminado')} · ${e.units>1?`${e.units} números · `:''}${esc(e.date)}</small></div><div class="play-money">${money(entryAmount(e))}<button data-delete-entry="${esc(e.id)}">Eliminar</button></div></div>`).join(''):'<div class="empty">Todavía no hay jugadas en esta sesión.</div>';
  }
  function renderAll(){renderPlayers();renderSession();renderHistory();makeReport();}
  function setPage(page){document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.page===page));document.querySelectorAll('.page').forEach(p=>p.classList.toggle('hidden',p.id!==`page-${page}`));if(page==='reportes')makeReport();if(page==='historial')renderHistory();}
  document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>setPage(b.dataset.page)));
  document.querySelectorAll('.session').forEach(b=>b.addEventListener('click',()=>{session=b.dataset.session;document.querySelectorAll('.session').forEach(x=>x.classList.toggle('active',x===b));renderSession();}));
  $('date').addEventListener('change',renderSession);
  $('player-form').addEventListener('submit',e=>{e.preventDefault();const name=$('player-name').value.trim();if(!name)return;if(players.some(p=>p.name.toLowerCase()===name.toLowerCase())){toast('Ese jugador ya existe.');return;}players.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()+Math.random()),name});save();$('player-name').value='';renderAll();$('player').value=players[players.length-1].id;toast('Jugador agregado.');});
  $('add-player-short').addEventListener('click',()=>{setPage('jugadores');$('player-name').focus();});
  $('players-list').addEventListener('click',e=>{const b=e.target.closest('[data-delete-player]');if(!b)return;const id=b.dataset.deletePlayer;if(!confirm('¿Eliminar este jugador? Las jugadas guardadas se conservarán y aparecerán como jugador eliminado.'))return;players=players.filter(p=>p.id!==id);save();renderAll();});
  $('session-plays').addEventListener('click',e=>{const b=e.target.closest('[data-delete-entry]');if(!b)return;if(!confirm('¿Eliminar esta jugada?'))return;entries=entries.filter(x=>x.id!==b.dataset.deleteEntry);save();renderAll();});
  function normalizeToken(s){s=s.trim().toUpperCase().replace(/[×*]/g,'X');if(/^L\d$/.test(s))return 'L0'+s.slice(1);if(/^T\d$/.test(s))return 'T'+s.slice(1);if(/^\d$/.test(s))return '0'+s;return s;}
  function expandToken(token){token=normalizeToken(token);if(/^\d{2}$/.test(token))return [token];if(/^L\d{2}$/.test(token)){const n=Number(token.slice(1));return Array.from({length:10},(_,i)=>String(n+i).padStart(2,'0'));}if(/^T\d$/.test(token)){const n=token.slice(1);return Array.from({length:10},(_,i)=>String(i)+n);}return null;}
  function canonicalPair(a,b){return [a,b].sort().join('x');}
  function parseLine(raw,index){
    let s=raw.trim().replace(/[–—]/g,'-').replace(/[×*]/g,'x');if(!s)return {skip:true};
    // Amount is the final number, with optional hyphen, "con", spaces, or parentheses.
    let m=s.match(/^(.*?)\s*(?:-\s*|\bcon\s*|\(\s*|\s+)(\d+(?:[.,]\d{1,2})?)\s*\)?$/i);
    if(!m)return {error:`Línea ${index+1}: no se pudo reconocer el importe en «${raw}».`};
    let left=m[1].trim().replace(/[()]$/g,'').trim();const amount=Number(m[2].replace(',','.'));
    if(!Number.isFinite(amount)||amount<0)return {error:`Línea ${index+1}: importe inválido.`};
    const parts=left.split(/\s*x\s*/i);if(parts.length>2||parts.some(p=>!p.trim()))return {error:`Línea ${index+1}: formato de parlet inválido.`};
    const tokens=parts.map(normalizeToken);const first=expandToken(tokens[0]);if(!first)return {error:`Línea ${index+1}: jugada «${tokens[0]}» no válida.`};
    if(parts.length===1){const type=/^L/.test(tokens[0])?'Línea':/^T/.test(tokens[0])?'Terminal':'Fijo';return {raw,display:tokens[0],type,amount,units:first.length,keys:first.map(n=>n),line:index+1};}
    const second=expandToken(tokens[1]);if(!second)return {error:`Línea ${index+1}: segundo número «${tokens[1]}» no válido.`};
    const pairs=[];for(const a of first)for(const b of second){if(a!==b)pairs.push(canonicalPair(a,b));}
    const unique=[...new Set(pairs)];const leftDisplay=tokens[0],rightDisplay=tokens[1];const display=leftDisplay+'x'+rightDisplay;
    return {raw,display,type:'Parlet',amount,units:unique.length,keys:unique,line:index+1};
  }
  function prepare(){
    const playerId=$('player').value;if(!playerId){toast('Primero selecciona o agrega un jugador.');return;}
    const lines=$('plays').value.split(/\r?\n/);const parsed=[],errors=[];lines.forEach((line,i)=>{const r=parseLine(line,i);if(r.skip)return;if(r.error)errors.push(r.error);else parsed.push({...r,playerId,date:currentDate(),session,id:(crypto.randomUUID?crypto.randomUUID():String(Date.now()+Math.random()))});});
    if(!parsed.length){pending=[];$('save-plays').disabled=true;toast(errors.length?'Corrige las líneas marcadas.':'Pega al menos una jugada.');$('preview-area').classList.remove('hidden');$('preview-summary').textContent='No se encontraron jugadas válidas.';$('preview-list').innerHTML=errors.map(x=>`<div class="invalid">${esc(x)}</div>`).join('');return;}
    // Compare each expanded number or parlet with already saved plays for the same date/session and within this pasted batch.
    const existing=forSession().filter(e=>e.date===currentDate());const seen=new Map();existing.forEach(e=>(e.keys||[]).forEach(k=>seen.set(k,e)));
    let dupCount=0;parsed.forEach(p=>{p.duplicates=[];p.keys.forEach(k=>{if(seen.has(k)){p.duplicates.push({key:k,source:'guardada'});dupCount++;}else if(p.duplicatesBatchSeen){} });p.keys.forEach(k=>{if(!seen.has(k))seen.set(k,p);});});
    // Detect duplicates inside the batch separately, including reversed parlets.
    const batchSeen=new Map();parsed.forEach(p=>{p.batchDuplicates=[];p.keys.forEach(k=>{if(batchSeen.has(k)){p.batchDuplicates.push(k);dupCount++;}else batchSeen.set(k,p);});});
    pending=parsed;$('save-plays').disabled=!pending.length;$('preview-area').classList.remove('hidden');$('preview-summary').textContent=`${parsed.length} línea(s) válida(s), ${money(parsed.reduce((a,p)=>a+p.amount*p.units,0))} de importe total expandido. ${dupCount?`Se detectaron ${dupCount} coincidencia(s); revisa antes de guardar.`:'No se detectaron coincidencias con las jugadas guardadas ni dentro de la lista.'}`;
    $('preview-list').innerHTML=errors.map(x=>`<div class="invalid">${esc(x)}</div>`).join('')+parsed.map((p,i)=>{const d=[...new Set([...p.duplicates.map(x=>x.key),...p.batchDuplicates])];return `<div class="play-row"><div class="play-main"><strong>${esc(p.display)} <span class="badge-type">${esc(p.type)}</span></strong><small>Línea ${p.line} · ${p.units} número(s) · ${money(p.amount)} por número</small>${d.length?`<div class="duplicate">⚠ Coincide en: ${d.map(esc).join(', ')}. Si la mantienes, se guardará igualmente.</div>`:''}</div><div class="play-money">${money(p.amount*p.units)}<label class="hint"><input type="checkbox" data-skip="${i}" style="width:auto" checked> Mantener</label></div></div>`;}).join('');
  }
  $('preview').addEventListener('click',prepare);
  $('cancel-preview').addEventListener('click',()=>{$('preview-area').classList.add('hidden');pending=[];$('save-plays').disabled=true;});
  $('plays').addEventListener('input',()=>{pending=[];$('save-plays').disabled=true;$('preview-area').classList.add('hidden');});
  ['player','date'].forEach(id=>$(id).addEventListener('change',()=>{pending=[];$('save-plays').disabled=true;$('preview-area').classList.add('hidden');}));
  document.querySelectorAll('.session').forEach(b=>b.addEventListener('click',()=>{pending=[];$('save-plays').disabled=true;$('preview-area').classList.add('hidden');}));
  $('save-plays').addEventListener('click',()=>{if(!pending.length)return;const skipped=[...$('preview-list').querySelectorAll('[data-skip]:not(:checked)')].map(x=>Number(x.dataset.skip));const chosen=pending.filter((_,i)=>!skipped.includes(i));entries.push(...chosen);save();$('plays').value='';$('preview-area').classList.add('hidden');pending=[];$('save-plays').disabled=true;renderAll();toast(`Se guardaron ${chosen.length} jugada(s).`);});
  function renderHistory(){const date=$('history-date').value||today();const day=entries.filter(e=>e.date===date);const parts=['Mediodía','Noche'];$('history-content').innerHTML=parts.map(s=>{const arr=day.filter(e=>e.session===s);const total=sum(arr);return `<div class="history-session"><h3>${s} · ${arr.length} jugadas</h3><div class="metric"><small>Total jugado</small><strong>${money(total)}</strong><small>10 %: ${money(total*.1)} · Restante: ${money(total*.9)}</small></div>${arr.length?arr.map(e=>`<div class="play-row"><div class="play-main"><strong>${esc(e.display)}</strong><small>${esc(players.find(p=>p.id===e.playerId)?.name||'Jugador eliminado')}</small></div><div class="play-money">${money(entryAmount(e))}</div></div>`).join(''):'<p class="empty">Sin jugadas.</p>'}</div>`;}).join('');}
  $('history-date').addEventListener('change',renderHistory);
  function makeReport(){if(!$('report-date'))return;const date=$('report-date').value||today(),sess=$('report-session').value||'Ambas',pid=$('report-player').value||'Todos';const arr=entries.filter(e=>e.date===date&&(sess==='Ambas'||e.session===sess)&&(pid==='Todos'||e.playerId===pid));const total=sum(arr);$('report-total').textContent=money(total);$('report-fee').textContent=money(total*.1);$('report-net').textContent=money(total*.9);
    const title=`REPORTE DE BOLITA\nFecha: ${date.split('-').reverse().join('/')}\n${pid==='Todos'?'Todos los jugadores':`Jugador: ${players.find(p=>p.id===pid)?.name||'Jugador eliminado'}`}\n`;
    const selected=sess==='Ambas'?['Mediodía','Noche']:[sess];let body='';selected.forEach(s=>{const sub=arr.filter(e=>e.session===s);const st=sum(sub);body+=`\n${s.toUpperCase()}\n`;if(!sub.length)body+='Sin jugadas\n';else sub.forEach(e=>{const who=pid==='Todos'&&players.length>1?` (${players.find(p=>p.id===e.playerId)?.name||'Jugador eliminado'})`:'';body+=`${e.display}${who} — ${money(entryAmount(e))}\n`;});body+=`Total jugado: ${money(st)}\n10 %: ${money(st*.1)}\nRestante: ${money(st*.9)}\n`;});body+=`\nTOTAL DEL REPORTE\nJugado: ${money(total)}\n10 %: ${money(total*.1)}\nRestante: ${money(total*.9)}`;$('report-text').value=title+body;
  }
  ['report-date','report-session','report-player'].forEach(id=>$(id).addEventListener('change',makeReport));$('make-report').addEventListener('click',makeReport);$('copy-report').addEventListener('click',async()=>{makeReport();try{if(navigator.clipboard&&navigator.clipboard.writeText)await navigator.clipboard.writeText($('report-text').value);else{$('report-text').focus();$('report-text').select();document.execCommand('copy');}toast('Reporte copiado. Ya puedes pegarlo en WhatsApp.');}catch{$('report-text').focus();$('report-text').select();toast('Selecciona el texto y cópialo para pegarlo en WhatsApp.');}});
  renderAll();
})();
