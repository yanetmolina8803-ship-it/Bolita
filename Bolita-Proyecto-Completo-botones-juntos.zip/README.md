# Bolita — proyecto Android

Aplicación en español para registrar jugadores, fijos, líneas (L), terminales (T), parlets, sesiones de mediodía/noche, importes y reportes para WhatsApp. Los datos se guardan localmente en el dispositivo mediante almacenamiento del navegador/WebView.

## Construir la APK desde GitHub (teléfono Android)
1. Sube el contenido de este ZIP a la raíz de un repositorio GitHub nuevo. Asegúrate de que también se suba la carpeta oculta `.github/workflows`.
2. Abre la pestaña **Actions / Acciones** del repositorio y habilita los flujos si GitHub lo solicita.
3. En **Crear APK de Bolita**, pulsa **Run workflow / Ejecutar flujo de trabajo** si no se inició automáticamente.
4. Cuando termine en verde, abre esa ejecución y descarga **Bolita-APK-debug** en **Artifacts / Artefactos**.
5. Descomprime el artefacto descargado y abre `app-debug.apk` para instalarlo. Android puede pedir permiso para instalar desde esa fuente.

La APK de depuración sirve para instalar y probar; no es una publicación firmada para Play Store. Mantén una copia de seguridad de tus datos antes de borrar la aplicación o sus datos.
